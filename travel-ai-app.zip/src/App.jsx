import React from 'react';

function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Travel AI Planner ✈️</h1>
      <p>This is a sample AI-powered travel planner with working Vercel config.</p>
    </div>
  );
}

export default App;